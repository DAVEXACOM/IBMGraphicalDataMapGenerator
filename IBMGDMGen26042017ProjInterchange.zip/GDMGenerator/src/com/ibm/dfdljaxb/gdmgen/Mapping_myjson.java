package com.ibm.dfdljaxb.gdmgen;

public class Mapping_myjson
{
    private Mapping_context mapping_context;

    public Mapping_context getMapping_context ()
    {
        return mapping_context;
    }

    public void setMapping_context (Mapping_context mapping_context)
    {
        this.mapping_context = mapping_context;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [mapping_context = "+mapping_context+"]";
    }
}

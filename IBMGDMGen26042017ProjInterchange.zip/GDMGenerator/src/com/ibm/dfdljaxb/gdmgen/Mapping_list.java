package com.ibm.dfdljaxb.gdmgen;

public class Mapping_list
{
    private Mapping_item[] mapping_item;

    public Mapping_item[] getMapping_item ()
    {
        return mapping_item;
    }

    public void setMapping_item (Mapping_item[] mapping_item)
    {
        this.mapping_item = mapping_item;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [mapping_item = "+mapping_item+"]";
    }
}
			
			

Input_Model.xsd,inmodel,XMLNSC,Output_Model.xsd,outmodel,XMLNSC
input1,output1,copy,,uppercase,
input2,output2,copy,,substring to 20,


Had to change the output of the excel spreadsheet to remove the , delimited from the last field of the repeating
field mapping records by hand. Not ideal. I should be able to manage this in the DFDL message model. But the model looks
OK to me. field delimited with , and record with CRLF.

Input_Model.xsd,inmodel,XMLNSC,Output_Model.xsd,outmodel,XMLNSC
input1,output1,copy,,uppercase
input2,output2,copy,,substring to 20